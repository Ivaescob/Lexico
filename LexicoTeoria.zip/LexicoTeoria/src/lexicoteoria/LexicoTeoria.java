/*
Analizador lexico
 */
package lexicoteoria;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 @author dany
 */
public class LexicoTeoria extends Grafica { //Heredacion  de la clase grafica

   
    public static void main(String[] args) {
        // TODO code application logic here
       
      
       Analizador obj = new Analizador(); //Creacion del objeto analizador
       String token;  //Cadena de analizis
       Grafica data = new Grafica();//Objeto tipoo grafico inicializara todo el programa
       int control;
       
       data.main();// Manda llamar a la interfaz grafica, inicia todo el programa.
       
      
       

              
              
 }//Cierre del main
    
}//Cierre de la clase
