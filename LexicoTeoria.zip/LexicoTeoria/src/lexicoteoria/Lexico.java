/*
 Se implemento la interfaz para tener el cuerpo del analizador lexico y
  tener mayor control y seguridad del lexico
 */
package lexicoteoria;

/**
 *
 * @author dany
 */

public interface Lexico {
    public boolean palabrasReservadas(String token); //Checara si es palabra reserevada c++ y c
    public boolean palabrasReservadasC(String token); //Checara si es palabra reserevada c++
    public boolean signoReservado(String token);//Checar si es signo reservado
    public boolean operadorLogico(String token); // Checar si es or,and, xor
    public boolean operadorRelacional(String token);//Checara si es mayor, si es menor,igual
    public boolean operadorAritmetico(String token); // Checara si suma, divicion, resta, multiplicaion
    public boolean variables(String token);//Checara la delaracion de variables
    public boolean numerosEnterosFlotantes(String token);//Checara si son numeros enteros
    public boolean numerosFlotantes(String token);//Checara si son numeros flotabtes
    public boolean esLetra(char caracter);//Se comprueba que sea letra
    public boolean esDigito(char caracter);//Se comprueba que sea numeros
    enum Estados{};//manejador de estados
  
             
}
