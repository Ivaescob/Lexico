/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lexicoteoria;

import java.awt.TextArea;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import java.util.regex.*;
import javax.swing.JTextArea;

/**
 *
 * @author dany
 */
public class Analizador extends Grafica implements Lexico  { //Implementa la clase interfaz y hereda clase grafica
    
    
    
     
    Grafica dat = new Grafica();//Objeto tipo grafica, no se usa
    Estados estadoActual;//Estado del automanta
    public JTextArea objeto;
    
  
    public void AFD(String token) { //Compara la cadena, asta caer en una funcion.
        
        
        
       if(palabrasReservadas(token)){ 
           
          JOptionPane.showMessageDialog(null, "El token " + token + " es una palabra reservada de C y C++", "VACIO!", JOptionPane.WARNING_MESSAGE); 
       }
       else if(palabrasReservadasC(token)){ 
           
         
       JOptionPane.showMessageDialog(null, "El token " + token + " es una palbra reservada  exclusiva de C++", "VACIO!", JOptionPane.WARNING_MESSAGE); 
       }
       
       else if(operadorLogico(token)){ 
          
       JOptionPane.showMessageDialog(null, "El token " + token + " es un operador lógico", "VACIO!", JOptionPane.WARNING_MESSAGE); 
       }
       
       else if(signoReservado(token)){ 
         
              JOptionPane.showMessageDialog(null, "El token " + token + " es un signo reservado", "VACIO!", JOptionPane.WARNING_MESSAGE); 

       }
       
       else if(operadorRelacional(token)){
          
         JOptionPane.showMessageDialog(null, "El token " + token + " es un operador relacional", "VACIO!", JOptionPane.WARNING_MESSAGE); 

       
       }
       
       else if(operadorAritmetico(token)){ 
         
                JOptionPane.showMessageDialog(null, "El token " + token + " es un operador aritmetico", "VACIO!", JOptionPane.WARNING_MESSAGE); 

       }
       
       else if(numerosEnterosFlotantes(token)){ 
            
        JOptionPane.showMessageDialog(null, "El token " + token + " es un Numero entero o flotante", "VACIO!", JOptionPane.WARNING_MESSAGE); 

       }
       
       else if(variables(token)){ 
          
               JOptionPane.showMessageDialog(null, "El token " + token + " es una variable", "VACIO!", JOptionPane.WARNING_MESSAGE); 

       } 
       
     
       
       else{
           
           JOptionPane.showMessageDialog(null, "Poner cadena valida", "VACIO!", JOptionPane.WARNING_MESSAGE); 
           
       }
    }//fin metodo AFD 

    @Override
    public boolean palabrasReservadas(String token) {
        
        
        String reservadas[] = {"auto",    "else",       "enum",         "if",          
                              "const",     "for",       "goto",          "return",        
                              "double",   "else",    "register",         "static",            
                              "float",    "long",      "sizeof",          "union",   
                              "int",    "signed",     "typedef",       "while",              
                              "short",   "switch",    "volatile",     "procedure",        
                              "struct",    "void",        "char",      "include",              
                              "unsigned",   "case",        "do",                      
                              "break",     "default",    "extern",     "continue"}; //Arreglo de palabras c y c++
        
        for (int i = 0; i < reservadas.length; i++) { //Para recorrer todo el arreglo
                if( reservadas[i].equals(token) ){ //Compara que sean iguales si son iguales, lanza true
                   
                    return true; //Si el token se encuentra en el arreglo es una palabra reservada
                }   
         }//Cierre del for
        
        
        return false;// Regresa falso si no es reservada
        
    }

    @Override
    public boolean palabrasReservadasC(String token) {
      String reservadasc[] = {"asm",          "dynamic_cast",       "namespace",       "reinterpret_cast",          
                              "try",          " bool",             "explicit",        "new",        
                              "static_cast",   " typeid",           "catch",         "false",            
                              "operator",      "template",         "typename",        "class",   
                              " friend",       "private",         "this",             "using",              
                              "const_cast ",   "inline",          "public",           "throw ",        
                              "virtual",       "delete",        "mutable",            "protected",              
                              " true",       "wchar_t",         "cin",              "cout"}; //Palbras reservadas de c++
        
        for (int i = 0; i < reservadasc.length; i++) { //Recorre el arreglo
                if( reservadasc[i].equals(token) ){//compara que sean iguales las palabras
                   
                    return true; //Si el token se encuentra en el arreglo es una palabra reservada
                }   
         }//Cierre del for
        
        
        return false;// Regresa falso si no es reservada
    
    
    }
    
    @Override
    public boolean signoReservado(String token) {
        Pattern logic = Pattern.compile("#|<<|>>|;");//carga el lenguaje
        Matcher save = logic.matcher(token); //Compra si estan de vuelve un boleano
       return save.matches(); //Devolucion tipo boleana, si es coincide es true si no false
    }

    
    @Override
    public boolean operadorLogico(String token) {
        Pattern logic = Pattern.compile(" bitor|and_eq|compl|not_eq|or_eq|xor_eq|bitand|not|and|or|xor");//carga el lenguaje
        Matcher save = logic.matcher(token); //Compra si estan de vuelve un boleano
         return save.matches(); //Devoluvion
    }

    @Override
    public boolean operadorRelacional(String token) {
        char or = 179;
        char or2 = 179;
       Pattern logic = Pattern.compile(">|<|>=|<=|==|&&|II|=");//carga el lenguaje
       Matcher save = logic.matcher(token); //Compra si estan de vuelve un boleano
        return save.matches(); //Devoluvion
    }

    @Override
    public boolean operadorAritmetico(String token) {
        char menos = 45;    //Simbolo: - (en caracteres ASCII)    
        Pattern aritmeticos = Pattern.compile("[+|-|*|/|"+menos+"]");// Operaciones
        Matcher save = aritmeticos.matcher(token);
        return save.matches();
    }

    @Override
    public boolean variables(String token)  {
        int estadoSiguiente; //De claracion de tipo entero para manejar el estado siguiente
        boolean bandera;//Bnadera para controlar que sean estado validos
       char arregloToken[] = token.toCharArray(); //Descompone el token, en un arrelo de letras 
       estadoActual = Estados.q0;//Se inicializa el estdo de q0
        for(int i = 0;i < arregloToken.length;i++){ 
               if(esLetra(arregloToken[i])) 
               { estadoSiguiente = 0; } //Estado valido a q0

               else if(esDigito(arregloToken[i])) 
               { estadoSiguiente = 1; }//Estado valido a q1

               else 
               {estadoSiguiente = 2;} //Estado invalido a q2
               
               

               estadoActual = afndVariables(estadoActual,estadoSiguiente);//saco el estado actual
               
               
            }//Cierre for
        if( estadoActual.equals(Estados.q0) || (estadoActual.equals(Estados.q1))){//Comparo si cai en estados validos
    
          bandera=true;
    }else{bandera=false;}
       
        return bandera;
    }

    @Override
    public boolean numerosEnterosFlotantes(String token) {
       int estadoSiguiente; 
       boolean bandera;
       char arregloToken[] = token.toCharArray(); 
       estadoActual = Estados.q0;
        for(int i = 0;i < arregloToken.length;i++){ 
               if(esDigito(arregloToken[i])) 
               { estadoSiguiente = 0; }

               else if(arregloToken[i]== '.') //Compara si es punto
               { estadoSiguiente = 1; }

               else 
               {estadoSiguiente = 2;}
               
               

               estadoActual = afndNumeros(estadoActual,estadoSiguiente);//saco el estado actual
               
               
            }//Cierre for
        
           if( estadoActual.equals(Estados.q0) || (estadoActual.equals(Estados.q1))){
    
          bandera=true;
    }else{bandera=false;}
       
        return bandera;
        
    }

  
    
    
    public Estados afndVariables(Estados estadoActual, int estadoSiguiente) {
        int estado; 
       Estados posicion;
               
        Estados matriz[][] = { {Estados.q0,Estados.q1,Estados.q2}, 
                                {Estados.q1,Estados.q1,Estados.q2}, 
                                {Estados.q2,Estados.q2,Estados.q2} }; //Tabla de tranciciones 
               
       estado = estadoActual.ordinal();// Indice de la constante
       System.out.println("Estado"+estado);
       posicion = matriz[estado][estadoSiguiente];
       System.out.println(posicion);//Me regresa la pocicion de la tabla de estados
       return posicion; 
    }

    public Estados afndNumeros(Estados estadoActual, int estadoSiguiente){
        int estado; 
       Estados posicion,matriz[][] = { {Estados.q0,Estados.q1,Estados.q2}, 
                                       {Estados.q1,Estados.q2,Estados.q2}, 
                                       {Estados.q2,Estados.q2,Estados.q2} }; //q00 y q01 -> estados válidos 
       estado = estadoActual.ordinal();// Indice de la constante
       System.out.println("Estado"+estado);
       posicion = matriz[estado][estadoSiguiente];
       System.out.println(posicion);//Me regresa la pocicion de la tabla de estados
       return posicion; 
     
     }
     
     
    @Override
    public boolean esLetra(char caracter) {
        return ((caracter >= 'A' && caracter <= 'Z')||(caracter >= 'a' && caracter <= 'z'));//Compara si son caracteres
    }

    @Override
    public boolean esDigito(char caracter) {
         return ((caracter >= '0' && caracter <= '9')); 
    }

    @Override
    public boolean numerosFlotantes(String token) {
        throw new UnsupportedOperationException("Not supported yet."); //No se usa
    }

    
 
    
    public enum Estados { 
        q0, q1, q2, q3, q4, 
   } //estados usados para validar si son variables, numeros y numeros flotantes
}

  
  
     

